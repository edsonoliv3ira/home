
package org.arpit.javapostsforlearning.webservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.arpit.javapostsforlearning.webservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConsultaReq_QNAME = new QName("http://webservice.javapostsforlearning.arpit.org/", "consultaReq");
    private final static QName _ConsultaReqResponse_QNAME = new QName("http://webservice.javapostsforlearning.arpit.org/", "consultaReqResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.arpit.javapostsforlearning.webservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsultaReq_Type }
     * 
     */
    public ConsultaReq_Type createConsultaReq_Type() {
        return new ConsultaReq_Type();
    }

    /**
     * Create an instance of {@link ConsultaReqResponse }
     * 
     */
    public ConsultaReqResponse createConsultaReqResponse() {
        return new ConsultaReqResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsultaReq_Type }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.javapostsforlearning.arpit.org/", name = "consultaReq")
    public JAXBElement<ConsultaReq_Type> createConsultaReq(ConsultaReq_Type value) {
        return new JAXBElement<ConsultaReq_Type>(_ConsultaReq_QNAME, ConsultaReq_Type.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsultaReqResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://webservice.javapostsforlearning.arpit.org/", name = "consultaReqResponse")
    public JAXBElement<ConsultaReqResponse> createConsultaReqResponse(ConsultaReqResponse value) {
        return new JAXBElement<ConsultaReqResponse>(_ConsultaReqResponse_QNAME, ConsultaReqResponse.class, null, value);
    }

}
