package org.arpit.javapostsforlearning.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
 
@WebService
public interface ConsultaReq {
 
 @WebMethod public String consultaReq(String name);
}