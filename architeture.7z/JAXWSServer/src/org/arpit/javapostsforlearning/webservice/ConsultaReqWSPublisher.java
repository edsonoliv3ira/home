package org.arpit.javapostsforlearning.webservice;
import javax.xml.ws.Endpoint;

public class ConsultaReqWSPublisher {
 public static void main(String[] args) {
  Endpoint.publish("http://localhost:8080/WS/ConsultaReq",new ConsultaReqImpl());
 }
}