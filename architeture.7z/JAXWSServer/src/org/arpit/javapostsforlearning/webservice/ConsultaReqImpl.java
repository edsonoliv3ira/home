package org.arpit.javapostsforlearning.webservice;

import javax.jws.WebService;

@WebService(endpointInterface="org.arpit.javapostsforlearning.webservice.ConsultaReq")
public class ConsultaReqImpl implements ConsultaReq{
 
 public String consultaReq(String name) {
  return "Hello world from "+name;
 }
 
}
 