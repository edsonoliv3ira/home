package org.arpit.javapostsforlearning.webservice.client;
import org.arpit.javapostsforlearning.webservice.ConsultaReq;
import org.arpit.javapostsforlearning.webservice.ConsultaReqImplService;
 
public class JAXWSClient {
 
    /**
     * @author Arpit Mandliya
     */
    public static void main(String[] args) {
        
    	ConsultaReqImplService vService = new ConsultaReqImplService();
    	ConsultaReq vConsultaReq = vService.getConsultaReqImplPort();
        System.out.println(vConsultaReq.consultaReq("Arpit"));
    }
}
